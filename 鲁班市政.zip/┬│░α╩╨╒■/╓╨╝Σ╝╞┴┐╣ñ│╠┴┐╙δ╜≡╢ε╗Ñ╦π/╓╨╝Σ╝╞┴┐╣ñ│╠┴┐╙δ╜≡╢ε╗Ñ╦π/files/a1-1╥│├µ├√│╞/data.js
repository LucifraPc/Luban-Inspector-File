﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,[j,k,l,m,n,o],p,_(q,r,s,t,u,v,w,_(),x,_(y,z,A,B,C,_(D,E,F,G),H,null,I,B,J,B,K,L,M,null,N,O,P,Q,R,S,T,O),U,_(),V,_(),W,_(X,[])),Y,_(),Z,_());}; 
var b="url",c="a1-1页面名称.html",d="generationDate",e=new Date(1527761558650.47),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="variables",j="password",k="changephonenumber",l="emailaddress",m="passwordOKtips",n="password2",o="changepassword_",p="page",q="packageId",r="bf33f3daafcb488ba423f0d25c053750",s="type",t="Axure:Page",u="name",v="A1-1页面名称",w="notes",x="style",y="baseStyle",z="627587b6038d43cca051c114ac41ad32",A="pageAlignment",B="near",C="fill",D="fillType",E="solid",F="color",G=0xFFFFFFFF,H="image",I="imageHorizontalAlignment",J="imageVerticalAlignment",K="imageRepeat",L="auto",M="favicon",N="sketchFactor",O="0",P="colorStyle",Q="appliedColor",R="fontName",S="Applied Font",T="borderWidth",U="adaptiveStyles",V="interactionMap",W="diagram",X="objects",Y="masters",Z="objectPaths";
return _creator();
})());